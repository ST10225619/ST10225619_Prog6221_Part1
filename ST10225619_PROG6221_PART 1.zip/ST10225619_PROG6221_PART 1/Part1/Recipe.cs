﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{
    internal class Recipe
    {
        //Declaration of global variables- arrays to store
        private String[] ingredName;
        private String[] ingredUnits;
        private double[] ingredQauntity;
        private String[] ingredSteps;
        public int numIngredients;
        public int numbSteps;
        //These are the new Qauntities after the scaling
        public double newQauntity1;
        public double newQauntity2;
        public double newQauntity3;
        public void captureRecipeDetails()
        {
            Console.WriteLine("Enter the number of Ingredients you will capture:");
            int numIngredients = Convert.ToInt32(Console.ReadLine());

            ingredName = new String[numIngredients];
            ingredQauntity = new double[numIngredients];
            ingredUnits = new String[numIngredients];

            //for loop to count and store accordingly with the number of ingredients
            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter the Ingrediant Name {i + 1}: ");
                ingredName[i] = Console.ReadLine();

                Console.Write($"Enter the Ingrediant Qaunitity {i + 1}:");
                ingredQauntity[i] = Convert.ToDouble(Console.ReadLine());

                Console.Write($"Enter the Unit of the ingredient {i + 1}:");
                ingredUnits[i] = Console.ReadLine();

            }
            //Asks the user for the number of steps then will store it in the steps array

            Console.Write("Enter the number of steps: ");
            int numSteps = Convert.ToInt32(Console.ReadLine());

            ingredSteps = new string[numSteps];

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                ingredSteps[i] = Console.ReadLine();
            }

            Console.WriteLine("*******************************************************************");
            Console.WriteLine("*******************************************************************");
            
        }
        //method to display the ingredients of the recipe
        public void displayRecipe()
        {
            Console.WriteLine("****************************Recipe****************************");
            for (int i = 0; i < ingredName.Length; i++)
            {
                Console.WriteLine($"--------------Ingredient {i + 1}--------------");
                Console.WriteLine($"Ingredient Name: {ingredName[i]}");
                Console.WriteLine($"Ingredient Qauntity:{ingredQauntity[i]}");
                Console.WriteLine($"Ingredient Units: {ingredUnits[i]}");
            }
            Console.WriteLine("\nSteps");
            for (int i = 0; i < ingredSteps.Length; i++)
            {
                Console.WriteLine($"Step {i + 1}:" + ingredSteps[i]);
            }

            Console.WriteLine("*******************************************************************");
            Console.WriteLine("*******************************************************************");

        }
        //method to scale the ingredients by provided factors
        public void scaleIngredients()
        {
            //These are factors that user will scale by-They will select the number from options displayed
            double scaleFactor1 = 0.5;
            int scaleFactor2 = 2;
            int scaleFactor3 = 3;

            Console.WriteLine("You have selected to scale the recipe!!!");

            Console.WriteLine("What would you like to scale your recipe by?");
            Console.WriteLine("1- 0.5 (half)");
            Console.WriteLine("2- 2 (double)");
            Console.WriteLine("3- 3 (triple)");
            int scaleFactorChoice;
            scaleFactorChoice = Convert.ToInt32(Console.ReadLine());
            switch (scaleFactorChoice)
            {
                //Different cases for different factors that user chose to scale
                case 1:
                    for (int i = 0; i < ingredQauntity.Length; i++)
                    {
                        newQauntity1 = ingredQauntity[i] * scaleFactor1;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"--------------Ingredient {i + 1}--------------");
                        Console.WriteLine($"Ingredient Name: {ingredName[i]}");
                        Console.WriteLine($"New Ingredient Qauntity:{newQauntity1}");
                        Console.WriteLine($"Ingredient Units: {ingredUnits[i]}");
                    }
                    Console.WriteLine("\nSteps");
                    for (int i = 0; i < ingredSteps.Length; i++)
                    {
                        Console.WriteLine($"Step {i + 1}:" + ingredSteps[i]);
                    }
                    break;
                case 2:
                    for (int i = 0; i < ingredQauntity.Length; i++)
                    {
                        newQauntity2 = ingredQauntity[i] * scaleFactor2;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"--------------Ingredient {i + 1}--------------");
                        Console.WriteLine($"Ingredient Name: {ingredName[i]}");
                        Console.WriteLine($"New Ingredient Qauntity:{newQauntity2}");
                        Console.WriteLine($"Ingredient Units: {ingredUnits[i]}");
                    }
                    Console.WriteLine("\nSteps");
                    for (int i = 0; i < ingredSteps.Length; i++)
                    {
                        Console.WriteLine($"Step {i + 1}:" + ingredSteps[i]);
                    }
                    break;
                case 3:
                    for (int i = 0; i < ingredQauntity.Length; i++)
                    {
                        newQauntity3 = ingredQauntity[i] * scaleFactor3;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"--------------Ingredient {i + 1}--------------");
                        Console.WriteLine($"Ingredient Name: {ingredName[i]}");
                        Console.WriteLine($"New Ingredient Qauntity:{newQauntity3}");
                        Console.WriteLine($"Ingredient Units: {ingredUnits[i]}");
                    }
                    Console.WriteLine("\nSteps");
                    for (int i = 0; i < ingredSteps.Length; i++)
                    {
                        Console.WriteLine($"Step {i + 1}:" + ingredSteps[i]);
                    }
                    break;
            }


        }
        //method to reset to original values 
        //I just took the new Qauntities after scaling and just eqauted them to the original as they are all global variables
        public void resetToOriginalValues()
        {
            for (int i = 0; i < ingredQauntity.Length; i++)
            {
                //Setting all the newQaunitities after scaling to the original input
                newQauntity1 = ingredQauntity[i];
                newQauntity2 = ingredQauntity[i];
                newQauntity2 = ingredQauntity[i];
            }
        }

        //method to clear recipe by setting all the arrays to NULL
        public void clearRecipe()
        {
            //Set all arrays to null to clear them.
            ingredName = null;
            ingredQauntity = null;
            ingredUnits = null;
            ingredSteps = null;
           

             captureRecipeDetails();
        }
        //method to exit the program
        public void exitProgram()
        {
            Environment.Exit(0);
        }
    }
}
