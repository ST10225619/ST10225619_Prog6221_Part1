﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{


    class Program
    {
       
        static void Main(string[] args)
        {
            Recipe obj = new Recipe();
            {
                
                while (true)
                {
                    //Setting the menu to bethe clolour blue 
                    Console.ForegroundColor = ConsoleColor.Blue;
                    //Creating a menu Option
                    Console.WriteLine("1- Enter the Ingredients:");
                    Console.WriteLine("2- Display the Recipe:");
                    Console.WriteLine("3- Scale the Ingredients:");
                    Console.WriteLine("4- Reset to Original Values:");
                    Console.WriteLine("5- Clear Data and Enter new Recipe");
                    Console.WriteLine("6- Exit the Program:");
                    Console.ForegroundColor = ConsoleColor.White;
                    int menuResponse = Convert.ToInt32(Console.ReadLine());
                    
                    //Switch Case to call different methods for their different functions
                    switch (menuResponse)
                    {
                        case 1:
                            obj.captureRecipeDetails();
                            break;
                        case 2:
                            obj.displayRecipe();
                            break;
                        case 3:
                            obj.scaleIngredients();
                            break;
                        case 4:
                            obj.resetToOriginalValues();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Values have been RESET");
                            Console.ForegroundColor = ConsoleColor.White;
                            break;
                        case 5:
                            //Confirming with the user if they are sure with reseting and capturing new ingredients 
                            Console.Write("Are you sure you want to Reset all valuesAnd capture new Ingredients" +
                                "\n1- Yes" +
                                "\n2- No" +
                                "\nEnter Choice (number):");
                            int confirm = Convert.ToInt32(Console.ReadLine());
                            if (confirm == 1)
                            {

                                obj.clearRecipe();
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("You have opted not to reset");
                                Console.ReadKey();
                            }

                            break;
                        case 6:
                            obj.exitProgram();
                            break;

                    }
                }

            }

        }
    }
}
